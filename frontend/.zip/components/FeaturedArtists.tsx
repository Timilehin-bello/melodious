"use client";
import React from "react";
import Image from "next/image";
import useFetch from "@/hooks/useFetch";

const FeaturedArtists = () => {
  const {
    data: featuredArtists,
    loading,
    error,
  } = useFetch("/api/artists/featured");

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error fetching featured artists</div>;
  }

  return (
    <section className="bg-[url('/images/landing/background2.svg')] bg-cover bg-center text-white py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">
          Featured Artists
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {featuredArtists &&
            (featuredArtists as any).map((artist: any) => (
              <div key={artist.id} className="text-center">
                <Image
                  src={artist.avatar}
                  alt={artist.name}
                  width={150}
                  height={150}
                  className="mx-auto rounded-full mb-4"
                />
                <h3 className="text-xl font-bold">{artist.name}</h3>
              </div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedArtists;
