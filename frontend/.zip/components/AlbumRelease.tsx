const AlbumRelease = () => {
  return <div>AlbumRelease</div>;
};

export default AlbumRelease;
