"use client";
import React from "react";

const HowItWorks = () => {
  return (
    <section className="bg-gray-900 text-white py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <h3 className="text-2xl font-bold mb-4">1. Connect Your Wallet</h3>
            <p>
              Connect your favorite wallet to start streaming music and
              supporting artists.
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-4">2. Subscribe to a Plan</h3>
            <p>
              Choose a subscription plan that fits your needs to unlock
              exclusive features.
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-4">3. Earn Rewards</h3>
            <p>
              Earn rewards by streaming music, referring friends, and
              supporting your favorite artists.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
