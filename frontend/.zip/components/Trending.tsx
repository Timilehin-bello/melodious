"use client";
import React from "react";
import Image from "next/image";
import useFetch from "@/hooks/useFetch";

const Trending = () => {
  const { data: trendingSongs, loading, error } = useFetch("/api/trending");

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error fetching trending songs</div>;
  }

  return (
    <section className="bg-[url('/images/landing/background2.svg')] bg-cover bg-center text-white py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">
          Trending Songs
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {trendingSongs &&
            (trendingSongs as any).map((song: any) => (
              <div
                key={song.id}
                className="bg-gray-800 rounded-lg p-4 text-center"
              >
                <Image
                  src={song.cover}
                  alt={song.title}
                  width={200}
                  height={200}
                  className="mx-auto rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold">{song.title}</h3>
                <p className="text-gray-400">{song.artist}</p>
              </div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default Trending;
