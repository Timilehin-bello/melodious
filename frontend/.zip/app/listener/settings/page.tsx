const page = () => {
  return <div className="text-white mt-4 px-4">Settings Page</div>;
};

export default page;
